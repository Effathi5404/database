package PPS_Project.web.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.x.protobuf.MysqlxCrud.Projection;

import PPS_Project.DAO.User_DAO;
import PPS_Project.bean.User;

/**
 * Servlet implementation class User_Servlet
 */
@WebServlet("/")
public class User_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private User_DAO userDAO;
	private project1 project;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public User_Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		userDAO = new User_DAO();
		project=new project1();
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String action = request.getServletPath();
        System.out.println(action);
       
        try {
            switch (action) {
            case "/login":
                System.out.println("The action is: login");
                loginUser(request, response);
                break;
            case "/new":
                System.out.println("The action is: new");
                showNewForm(request, response);
                break;
            case "/insert":
                System.out.println("The action is: insert");
            	insertUser(request, response);
                break;
            case "/delete":
                System.out.println("The action is: delete");
            	deleteUser(request, response);
                break;
            case "/edit":
                System.out.println("The action is: edit");
                showEditForm(request, response);
                break;
            case "/update":
                System.out.println("The action is: update");
                updateUser(request, response);
                break;
            case "/welcome": 
    		    
    		    System.out.println("The action is: initialize");
    		    try {
    				root( );
    				newpage(request, response);
    			} catch (SQLException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    		         	
    		    break;
            default:
                System.out.println("Not sure which action, we will treat it as the list action");
                showDashboardPage(request, response);           	
                break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    
	}
	
	// login user
    private void loginUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException, ServletException {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		User user = userDAO.validateUser(email, password);
		
		System.out.println("is user null? " + userDAO == null );
		
		// validate input data.
		StringBuilder errorBuf = new StringBuilder();

		if ((email == null) || email.trim().equals("")) {
			email = "";
			errorBuf.append("Required:  Email. <br>");
		}

		if ((password == null) || password.trim().equals("")) {
			password = "";
			errorBuf.append("Required:  password. <br>");
		}

		String errorMessage = errorBuf.toString();
		if (!errorMessage.isEmpty()) {
			request.setAttribute("errorMessage", errorBuf.toString());
			request.getRequestDispatcher("user-loginForm.jsp").forward(request, response);
			return;

		}
		
		if (user != null) {
			if(user.getUser_id().equals("root")) {
				//response.sendRedirect("show");
				RequestDispatcher dispatcher = request.getRequestDispatcher("root.jsp");
		        dispatcher.forward(request, response);
				System.out.println("login success");	
			} else {
				//response.sendRedirect("show");
				RequestDispatcher dispatcher = request.getRequestDispatcher("user-welcomePage.jsp");
		        dispatcher.forward(request, response);
				System.out.println("login success"); }
			}
		else {
			//response.sendRedirect("login");
			request.setAttribute("errorMessage", "Invalid User account / password. <br>");
			RequestDispatcher dispatcher = request.getRequestDispatcher("user-loginForm.jsp");
	        dispatcher.forward(request, response);
	        System.out.println("login failed");
			}
		
	}
	
	// Show the sign-up form
    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("showNewForm started: 000000000000000000000000000");
     
        RequestDispatcher dispatcher = request.getRequestDispatcher("user-signupForm.jsp");
        dispatcher.forward(request, response);
        System.out.println("The user sees the InsertPeopleForm page now.");
     
        System.out.println("showNewForm finished: 1111111111111111111111111111111");
    }
    
    //int t =0;
    // Insert new user
    private void insertUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException, ServletException {
    	String errorMessage = "";
    	String email = request.getParameter("email");
    	User user = userDAO.selectUser(email);
    	
    	
    	if (user != null) {
			//response.sendRedirect("show");
    		errorMessage += "Account already exists for User email: <br>" + email
					+ "<br><br> Please Login with your email and password." + "<br>";

			request.setAttribute("errorMessage", errorMessage);
			RequestDispatcher dispatcher = request.getRequestDispatcher("user-loginForm.jsp");
	        dispatcher.forward(request, response);
			System.out.println("signup failed");
			}
		else {
			//response.sendRedirect("login");
			String password = request.getParameter("password");
			String fname = request.getParameter("fname");
			String lname = request.getParameter("lname");
			String address = request.getParameter("address");
			String dob = request.getParameter("dob");
			User newUser = new User(email, password,  fname, lname, address, dob);
			userDAO.insertUser(newUser);
			RequestDispatcher dispatcher = request.getRequestDispatcher("user-loginForm.jsp");
			String message = "Signup Successful! <br>";
			request.setAttribute("message", message);
	        dispatcher.forward(request, response);
	        System.out.println("signup success");
			}
    	
		//response.sendRedirect("login");
	}
    private void root() throws SQLException {
    
        project.part1();
 

}
    // Delete a user
    private void deleteUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		String email = request.getParameter("email");
		userDAO.deleteUser(email);
		response.sendRedirect("show");

	}
    
    // Show edit from to update
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
    	String email = request.getParameter("email");
		User existingUser = userDAO.selectUser(email);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-updateForm.jsp");
		request.setAttribute("user", existingUser);
		dispatcher.forward(request, response);
	}
    
    // Update the user info
    private void updateUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
    	String email = request.getParameter("email");
    	String password = request.getParameter("password");
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String address = request.getParameter("address");
		String dob = request.getParameter("dob");
		
		User user = new User(email, password ,fname, lname, address, dob);
		userDAO.updateUser(user);
		
		response.sendRedirect("show");
	}
    private void newpage(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException, ServletException {
    	
    	RequestDispatcher dispatcher = request.getRequestDispatcher("new.jsp");
    	dispatcher.forward(request, response);
	}
    
    // Default: show dashboard page
    private void showDashboardPage (HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		//request.setAttribute("listUser", listUser);
		//dispatcher.forward(request, response);
	}

	

}
