package PPS_Project.web.servlets;

import java.sql.SQLException;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class project1 {
	
	
	
	

	/**
	 * 
	 * @throws SQLException
	 */
	
	
	
	private static final long serialVersionUID = 1L;
	private Connection connect = null;
	private Connection connect1 = null;
	private Statement statement = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet resultSet = null;
	

    
	
	
    public void part1() throws SQLException {
    	
    	
    	try {
    		
    		if (connect == null || connect.isClosed()) {
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                } catch (ClassNotFoundException e) {
                    throw new SQLException(e);
                }
                connect = (Connection) DriverManager
      			      .getConnection("jdbc:mysql://127.0.0.1:3306/pps_db?"
      			          + "useSSL=false&user=john&password=john1234");
                System.out.println(connect);
            }
        
    
    		
    		
    		
    	
    		
    		
    		  statement = connect.createStatement();
    	String sql1 ="CREATE TABLE IF NOT EXISTS testusers " +
                "(email varchar(20), " +
                " firstName VARCHAR(20), " + 
                " lastName VARCHAR(20), " + 
                " street VARCHAR(20), " + 
                " Address VARCHAR(50), " + 
                " Status VARCHAR(10), " + 
                " PRIMARY KEY ( email ))";
    	
    	
    	String sql2 ="CREATE TABLE IF NOT EXISTS follow " +
                "(F_no integer , " +
                " follower_id VARCHAR(20), " + 
                " following_id VARCHAR(20), " + 
                "  PRIMARY KEY ( F_no ))";
                
    	
    	
    	String sql3 ="CREATE TABLE IF NOT EXISTS transfer" +
                "(trans_no integer , " +
                " sender_id VARCHAR(20), " + 
                " receiver_id VARCHAR(20), " + 
                " amount integer, " + 
                "  PRIMARY KEY ( trans_no ))" ;
               
    	
    	
    	
    	
    	String sql4 ="CREATE TABLE IF NOT EXISTS trade " +
                "(trade_no integer , " +
                " trader_id VARCHAR(20), " + 
                " buyamount integer, " + 
                " sellamount integer, " + 
                "  PRIMARY KEY ( trade_no ))" ;
                 
               
    	
    	String sql5="drop table if exists testusers";
    	String sql6="drop table if exists follow";
    	String sql7="drop table if exists transfer";
    	String sql8="drop table if exists trade";
    	
    	
    	
    	String sql9 = "insert into testusers(email,firstname,lastname,street,Address,Status) values('jerry@gamil.com','jen','try','123js','ctg','junior'),  ('promy@gamil.com','jen','try','123js','ctg','junior'),('sam@gamil.com','sam','try','123js','ctg','senior'),('tom@gamil.com','tom','try','123js','mi','senior'),('jack@gamil.com','jack','try','123js','ctg','junior'),('jill@gamil.com','jill','try','123js','ctg','junior'),('priya@gamil.com','priya','priti','123js','texas','junior'),('frank@gamil.com','frin','try','123js','ctg','junior'),('ash@gamil.com','ash','try','123js','ctg','junior'),('simi@gamil.com','simi','mary','123js','ctg','junior');";
    	String sql10 = "insert into follow(F_no,follower_id,following_id) values('1','123','4565'),  ('2','123','4565'),('3','68686123','9794565'),('4','12399','4565098'),('5','123','4565'),('6','123','4565'),('7','00123','4565'),('8','123','4565'),('9','87123','4565'),('10','123','4565');";
    	String sql11 = "insert into transfer(trans_no,sender_id,receiver_id,amount) values('1','123','4565','89'),  ('2','123','4565','1234'),('3','68686123','9794565','9876'),('4','12399','4565098','8765'),('5','123','4565','6788'),('6','123','4565','7654'),('7','00123','4565','789'),('8','123','4565','6578'),('9','87123','4565','987'),('10','123','4565','4567');";
    	
    	String sql12 = "insert into trade(trade_no,trader_id,buyamount,sellamount) values ('1','123','4565','89'),  ('2','123','4565','1234'),('3','68686123','9794565','9876'),('4','12399','4565098','8765'),('5','123','4565','6788'),('6','123','4565','7654'),('7','00123','4565','789'),('8','123','4565','6578'),('9','87123','4565','987'),('10','123','4565','4567');";

    	
   	 statement.executeUpdate(sql8);
	 statement.executeUpdate(sql7);

	 statement.executeUpdate(sql6);
	 statement.executeUpdate(sql5);
    	
    	
    	
    	
    	
    	
    	 statement.executeUpdate(sql1);
    	 statement.executeUpdate(sql2);

    	 statement.executeUpdate(sql3);
    	 statement.executeUpdate(sql4);
    	 statement.executeUpdate(sql9);
    	 statement.executeUpdate(sql10);
    	 
    	 statement.executeUpdate(sql11);
    	 statement.executeUpdate(sql12);
    	
    	
    	
    	
    	
    }
    	catch (Exception e) {
            System.out.println(e);
       } 
    }
    

}
